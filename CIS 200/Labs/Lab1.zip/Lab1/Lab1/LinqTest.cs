﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Grading ID:L5135
//Lab 1
//Due date:2/6/2019
//CIS 200-01
//This lab helps studetns better understand LINQ by sorting and calculating invoice information.

namespace Lab1
{
    public class LinqTest
    {
        public static void Main(string[] args)
        {
            // initialize array of invoices
            Invoice[] invoices = {
                new Invoice( 83, "Electric sander", 7, 57.98M ),
                new Invoice( 24, "Power saw", 18, 99.99M ),
                new Invoice( 7, "Sledge hammer", 11, 21.5M ),
                new Invoice( 77, "Hammer", 76, 11.99M ),
                new Invoice( 39, "Lawn mower", 3, 79.5M ),
                new Invoice( 68, "Screwdriver", 106, 6.99M ),
                new Invoice( 56, "Jig saw", 21, 11M ),
                new Invoice( 3, "Wrench", 34, 7.5M ) };

            // Display original array
            Console.WriteLine("Original Invoice Data\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");
            foreach (Invoice inv in invoices)
                Console.WriteLine(inv);

            //Sort invoices by Part Decription
            var partdescrip =
            from i in invoices // data source is invoices
          orderby i.PartDescription
            select i;

            //Display the Sorted Items by Part Decription
            Console.WriteLine("\nPart Description sorted:\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");
            foreach (var element in partdescrip)
            {
                Console.WriteLine(element);
            }

            //Sort invoices by Price
            var pricesort =
            from i in invoices // data source is invoices
            orderby i.Price
            select i;

            //Display the Sorted Items by Price
            Console.WriteLine("\nPrice sorted:\n");
            Console.WriteLine("P.Num Part Description     Quant Price");//Column Headers
            Console.WriteLine("----- -------------------- ----- ------");
            foreach (var element in pricesort)
            {
                Console.WriteLine(element);
            }

            // Sort by Quantity
            var partsort =
            from i in invoices
            orderby i.Quantity
            select new { i.PartDescription, i.Quantity };

            //Display the Sorted Items by Quantity
            Console.WriteLine("\nQuantity sorted:");
            Console.WriteLine("-----------------");

            foreach (var element in partsort)
            {
                Console.WriteLine(element);
            }
            //Calculate Invoice Total and sort by calculation
            var sortTotal =
            from i in invoices
            let total = i.Quantity * i.Price
            orderby total
            select new {i.PartDescription, InvoiceTotal = total};

         //Display the Sorted Items
        Console.WriteLine("\nInvoice Total Sorted:");
        Console.WriteLine("------------------------\n");
        Console.WriteLine("Part Description     Invoice Total");
            Console.WriteLine("----------------     --------------");

            foreach (var element in sortTotal)
            {
                Console.WriteLine($"{element.PartDescription,-20}");
                Console.WriteLine($"{element.InvoiceTotal,30:C}");
            }
        //Sort Inovoice Totals between $200-$500
            var sortbetweenamount =
            from i in sortTotal
            where (i.InvoiceTotal >= 200) && (i.InvoiceTotal<= 500)
            select i;

          //Display Invoice Totals between $200-$500
            Console.WriteLine("\nInvoice Totals between " + $"{200:C} - {500:C}:");
            Console.WriteLine("------------------------------------------");
            foreach (var element in sortbetweenamount)
            {
                Console.WriteLine($"{element.PartDescription,-20}");
                Console.WriteLine($"{element.InvoiceTotal,30:C}");
            }





        }
    }
}
