﻿// Program 2
// CIS 200-01
// Due: 3/8/2019
// By: L5135

// File: Prog2Form.cs
// This class creates the main GUI for Program 2. It provides a
// File menu with About and Exit items, an Insert menu with Patron and
// Book items, an Item menu with Check Out and Return items, and a
// Report menu with Patron List, Item List, and Checked Out Items items.

// Extra Credit - Check Out and Return only show relevant items

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;

namespace LibraryItems
{
    public partial class Prog2Form : Form
    {
        private BinaryFormatter formatter = new BinaryFormatter();
        private FileStream output;
        private FileStream input;
        private Library _lib; // The library

        // Precondition:  None
        // Postcondition: The form's GUI is prepared for display. A few test items and patrons
        //                are added to the library
        public Prog2Form()
        {
            InitializeComponent();

            _lib = new Library(); // Create the library

            // Insert test data - Magic numbers allowed here

        }

        // Precondition:  File, About menu item activated
        // Postcondition: Information about author displayed in dialog box
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine; // NewLine shortcut

            MessageBox.Show($"Program 2{NL}By: Andrew L. Wright{NL}CIS 200-01{NL}Spring 2019",
                "About Program 2");
        }

        // Precondition:  File, Exit menu item activated
        // Postcondition: The application is exited
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition:  Report, Patron List menu item activated
        // Postcondition: The list of patrons is displayed in the reportTxt
        //                text box
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryPatron> patrons;     // List of patrons
            string NL = Environment.NewLine; // NewLine shortcut

            patrons = _lib.GetPatronsList();

            reportTxt.Text = $"Patron List - {patrons.Count} patrons{NL}{NL}";

            foreach (LibraryPatron p in patrons)
                reportTxt.AppendText($"{p}{NL}{NL}");

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Report, Item List menu item activated
        // Postcondition: The list of items is displayed in the reportTxt
        //                text box
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryItem> items;         // List of library items
            string NL = Environment.NewLine; // NewLine shortcut

            items = _lib.GetItemsList();

            reportTxt.Text = $"Item List - {items.Count} items{NL}{NL}";

            foreach (LibraryItem item in items)
                reportTxt.AppendText($"{item}{NL}{NL}");

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Report, Checked Out Items menu item activated
        // Postcondition: The list of checked out items is displayed in the
        //                reportTxt text box
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryItem> items;         // List of library items
            string NL = Environment.NewLine; // NewLine shortcut

            items = _lib.GetItemsList();

            // LINQ: selects checked out items
            var checkedOutItems =
                from item in items
                where item.IsCheckedOut()
                select item;

            reportTxt.Text = $"Checked Out Items - {checkedOutItems.Count()} items{NL}{NL}";

            foreach (LibraryItem item in checkedOutItems)
                reportTxt.AppendText($"{item}{NL}{NL}");

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Insert, Patron menu item activated
        // Postcondition: The Patron dialog box is displayed. If data entered
        //                are OK, a LibraryPatron is created and added to the library
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatronForm patronForm = new PatronForm(); // The patron dialog box form

            DialogResult result = patronForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                // Use form's properties to get patron info to send to library
                _lib.AddPatron(patronForm.PatronName, patronForm.PatronID);
            }

            patronForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Insert, Book menu item activated
        // Postcondition: The Book dialog box is displayed. If data entered
        //                are OK, a LibraryBook is created and added to the library
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm(); // The book dialog box form

            DialogResult result = bookForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    // Use form's properties to get book info to send to library
                    _lib.AddLibraryBook(bookForm.ItemTitle, bookForm.ItemPublisher, int.Parse(bookForm.ItemCopyrightYear),
                        int.Parse(bookForm.ItemLoanPeriod), bookForm.ItemCallNumber, bookForm.BookAuthor);
                }

                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Book Validation!", "Validation Error");
                }
            }

            bookForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Item, Check Out menu item activated
        // Postcondition: The Checkout dialog box is displayed. If data entered
        //                are OK, an item is checked out from the library by a patron
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryItem> items;     // List of library items
            List<LibraryPatron> patrons; // List of patrons

            items = _lib.GetItemsList();
            patrons = _lib.GetPatronsList();

            if (((items.Count - _lib.GetCheckedOutCount()) == 0) || (patrons.Count() == 0)) // Must have items and patrons
                MessageBox.Show("Must have items and patrons to check out!", "Check Out Error");
            else
            {
                CheckoutForm checkoutForm = new CheckoutForm(items, patrons); // The check out dialog box form

                DialogResult result = checkoutForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    _lib.CheckOut(checkoutForm.ItemIndex, checkoutForm.PatronIndex);
                }

                checkoutForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }

        // Precondition:  Item, Return menu item activated
        // Postcondition: The Return dialog box is displayed. If data entered
        //                are OK, an item is returned to the library
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<LibraryItem> items;     // List of library items

            items = _lib.GetItemsList();

            if ((_lib.GetCheckedOutCount() == 0)) // Must have items to return
                MessageBox.Show("Must have items to return!", "Return Error");
            else
            {
                ReturnForm returnForm = new ReturnForm(items); // The return dialog box form

                DialogResult result = returnForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    _lib.ReturnToShelf(returnForm.ItemIndex);
                }

                returnForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }
        //Precondition: You must make sure there is test data so that you can save it onto a separate file.
        //Postcondition: The Library File will now be able to be saved
        private void saveLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //create and show dialog box enabling the user to save the file
            DialogResult result;//result of SaveFileDialog
            string fileName;//name of file containing data
            using (SaveFileDialog fileChooser = new SaveFileDialog())
            {
                fileChooser.CheckFileExists = false;//let the user create file
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;//name of file to save data
            }
            //ensure that user clicked "OK"
            if (result == DialogResult.OK)
            {
                //show error if user specified invalid file
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    //save file via FileStream
                    try 
                    {
                        //open file with write access
                        output = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
                        formatter.Serialize(output, _lib);
                        output?.Close();

                    }
                    catch (IOException)
                    {
                        //notify the user if the file does not exist
                        MessageBox.Show("Error saving file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }


                }

            }
        }
        //Precondition: You must make sure that you have created a separate file
        //Postcondition: You now will be able to opennn the Library File.
        private void openLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //create and show dialog box enabling user to open file
            DialogResult result; //result of OpenFileDialog
            string fileName;//name of file containing data
            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;//get specified name
            }
            //ensure the user clicked "OK"
            if (result == DialogResult.OK)
            {
                //shoe error if user specified invalid file 
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    //create FileStream to obtain read access to file
                    input = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                    _lib = (Library)formatter.Deserialize(input);
                }
            }

        }
        //Postcondition:There must already be a Library File created that includes patrons.
        //Precondition: This will ensure that the Patrons are outputted in a combobox and after the user chooses a patron, they are able to edit the existing patrons.
        private void patronToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            EditForm edit = new EditForm(); //Creating a new object edit
            foreach (LibraryPatron p in _lib.GetPatronsList())// Using a foreach loop to add the items to the ComboBox
            {
                edit.editComboBox.Items.Add(p.ToString());
            }
            DialogResult result = edit.ShowDialog();// The result will now equal the edit object
            if (result == DialogResult.OK)// If statement that is used to set the Patron Form object to the Library Patron p. This will give us the expected outcome.
            {
                LibraryPatron p;
                PatronForm patron = new PatronForm();
                p = _lib.GetPatronsList()[edit.editComboBox.SelectedIndex];
                patron.PatronName = p.PatronName;
                patron.PatronID = p.PatronID;
                DialogResult result2 = patron.ShowDialog(); //The result will now equal patron object.
                if (result2 == DialogResult.OK)//if statement setting the object p to the patron object.
                {
                    p.PatronName = patron.PatronName;
                    p.PatronID = patron.PatronID;
                }

            }

        }
        //Precondition:There must be a Library File created that includes books.
        //Postcondition: This will ensure that the books are outputted in a combobox and after the user selects a book, they are able to edit the existing books.
        private void bookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            List<LibraryBook> Books = new List<LibraryBook>(); //Creating a new list of books
            EditForm edit = new EditForm(); //creating the new object edit
            for (int i = 0; i < _lib.GetItemsList().Count; ++i)// For Loop that is finding out which items are books in the list of items.
            {
                if (_lib.GetItemsList()[i] is LibraryBook)
                {
                    edit.editComboBox.Items.Add(_lib.GetItemsList()[i].ToString());
                    Books.Add(_lib.GetItemsList()[i] as LibraryBook);
                }
            }
            DialogResult result = edit.ShowDialog();// The result will now equal the edit object


            LibraryBook b;    
                BookForm bookEditForm = new BookForm();
            b = Books[edit.editComboBox.SelectedIndex];

            string callNo = b.CallNumber;
            int itemindex = -1;
            for (int x = 0; x < _lib._items.Count; ++x) // Sequential Search Algorithm to find the items that are Books at their correct index. It does this by using the book call number.
            {
                if (_lib._items[x].CallNumber == callNo)
                {
                    itemindex = x;
                }
            }
            //The following code is used to set the Book Form object to the Library Book b. This will give us the expected outcome.
            bookEditForm.ItemTitle = b.Title;
                bookEditForm.ItemPublisher = b.Publisher;
                bookEditForm.ItemLoanPeriod = b.LoanPeriod.ToString();//converts the int to a string
                bookEditForm.ItemCopyrightYear = $"{b.CopyrightYear}";//converts the int to a string
                bookEditForm.ItemCallNumber = b.CallNumber;
                bookEditForm.BookAuthor = b.Author;
                DialogResult result2 = bookEditForm.ShowDialog();  //The result will now equal bookEditForm object.
            if (result2 == DialogResult.OK)//if statement setting the object b to the bookEditForm object.
            {
                    b.Title = bookEditForm.ItemTitle;
                    b.Publisher = bookEditForm.ItemPublisher;
                    b.LoanPeriod = int.Parse(bookEditForm.ItemLoanPeriod);//converts the string to int
                    b.CopyrightYear = int.Parse(bookEditForm.ItemCopyrightYear);//converts the string to int
                    b.CallNumber = bookEditForm.ItemCallNumber;
                    b.Author = bookEditForm.BookAuthor;
                }
            _lib.GetItemsList()[itemindex] = b; //This will retuen the list of books back to the original list of items.

            }
        }
    }


