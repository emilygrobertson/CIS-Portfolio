﻿// Program 2
// CIS 200-01
// Due: 3/7/2019
// By: L5135

// File: EditForm.cs
// This Form uses a combobox to output the Patrons and the Books.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditForm : Form
    {
        public EditForm()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK; //The Result will now equal OK.
            this.Close();// This closes the form.

        }
    }
}
