﻿//Grading ID: A4945
//CIS 199-01
//Lab 1
//Due 9/2/2018
//This is a Simple Lab
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_1
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Grading ID:A4945");
            System.Console.WriteLine("Hobbies: Reading, Watching Netflix, and hanging out with friends");
            System.Console.WriteLine("Favorite Book: Small Great Things by Jodi Picoult");
            System.Console.WriteLine("Favorite Movie: Wolf of Wall Street");
        }
    }
}
