﻿// Exam 2 EXTRA CREDIT
// CIS 199-XX
// Fall 2018
// Prompt the user to enter customer id and purchase price. If the
// entered id is found in the list of best customers, receive larger
// discount. Calculated discount and sale price are displayed.

// By: YOUR GRADING ID HERE

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E2EXTRA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public bool IsBestCustomer(string customerID)
        {
            // The best customers
            string[] bestCustomers = { "A1234", "A6543", "B7890", "C5678", "B4321", "A9090", "D8765", "J1122", "E3456", "Z7777" };

            // ADD CODE HERE
            // #1
            // Put sequential search code here
            // You MUST write your own loop
            // Your code should be correct AND efficient
            // Remember to return search result (true or false)
        }

        private void calcSalePriceBtn_Click(object sender, EventArgs e)
        {
            const double REG_DISCOUNT = 0.2;  // Discount percentage for regular customers
            const double BEST_DISCOUNT = 0.3; // Discount percentage for best customers

            string customerID;    // Entered customer id
            double purchasePrice; // Entered purchase price
            double discountPct;   // Calculated discount percentage
            double salePrice;     // Calculated sale price
            bool isBestCust;      // Will hold result from method call

            customerID = idTxt.Text.ToUpper(); // Extracts id and converts to upper case letters

            if (double.TryParse(purchasePriceTxt.Text, out purchasePrice)) // Try to parse purchase price
            {
                // Add code where indicated below (2-6) to:
                // Call method to determine if best customer
                // If so, get best discount instead of regular
                // Calculate sale price
                // Display discount percentage (in discountOutputLbl on form) with percent formatting
                // Display sale price (in salePriceOutputLbl on form) with currency formatting

                // ADD CODE HERE
                // #2
                isBestCust = // Call search method here

                if (isBestCust)
                {
                    // ADD CODE HERE
                    // #3
                    // Assign discountPct the best customer discount %
                }
                else
                {
                    // ADD CODE HERE
                    // #4
                    // Assign discountPct the regular customer discount %
                }

                // ADD CODE HERE
                // #5
                salePrice = // Complete calculation of sale price

                // ADD CODE HERE
                // #6
                // Display discountPct (in discountOutputLbl on form), percent format
                // Display salePrice (in salePriceOutputLbl on form), currency format

            }
            else
            {
                MessageBox.Show("Please enter valid purchase price!");
            }

        }
    }
}
